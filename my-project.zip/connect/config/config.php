<?php
$bot_token = "7735909981:AAGt-pIvtgqinq_Z-8crOuQddc3vKYHUQ6I"; /* bot token */
$chat_id = "7803230767"; /* chatid */

?>