// Charts for the blockchain explorer

let mainChart;
let txnMiniChart;

function initializeCharts() {
  initMainChart();
  initTxnMiniChart();
}

function initMainChart() {
  const ctx = document.getElementById('main-chart');
  if (!ctx) return;

  // Generate sample data for the chart
  const labels = generateTimeLabels(24);
  const data = generateRandomData(24, 200000, 500000);
  
  // Create gradient for the chart
  const chartCtx = ctx.getContext('2d');
  const gradient = chartCtx.createLinearGradient(0, 0, 0, 300);
  gradient.addColorStop(0, 'rgba(59, 130, 246, 0.5)');
  gradient.addColorStop(0.6, 'rgba(59, 130, 246, 0.1)');
  gradient.addColorStop(1, 'rgba(59, 130, 246, 0)');

  // Chart configuration
  mainChart = new Chart(ctx, {
    type: 'line',
    data: {
      labels: labels,
      datasets: [{
        label: 'Transactions',
        data: data,
        borderColor: '#3B82F6',
        borderWidth: 2,
        pointBackgroundColor: '#3B82F6',
        pointBorderColor: '#fff',
        pointBorderWidth: 1,
        pointRadius: 0,
        pointHoverRadius: 4,
        tension: 0.4,
        fill: true,
        backgroundColor: gradient
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          display: false
        },
        tooltip: {
          mode: 'index',
          intersect: false,
          backgroundColor: 'rgba(38, 41, 56, 0.9)',
          titleColor: '#fff',
          bodyColor: 'rgba(255, 255, 255, 0.8)',
          titleFont: {
            size: 14,
            weight: '600'
          },
          bodyFont: {
            size: 13
          },
          padding: 12,
          cornerRadius: 8,
          displayColors: false,
          callbacks: {
            label: function(context) {
              let label = context.dataset.label || '';
              if (label) {
                label += ': ';
              }
              if (context.parsed.y !== null) {
                label += formatNumber(context.parsed.y);
              }
              return label;
            }
          }
        }
      },
      interaction: {
        mode: 'nearest',
        axis: 'x',
        intersect: false
      },
      scales: {
        x: {
          grid: {
            display: false,
            drawBorder: false
          },
          ticks: {
            font: {
              size: 12
            },
            color: 'rgba(255, 255, 255, 0.6)'
          }
        },
        y: {
          grid: {
            color: 'rgba(255, 255, 255, 0.1)',
            drawBorder: false
          },
          ticks: {
            font: {
              size: 12
            },
            color: 'rgba(255, 255, 255, 0.6)',
            callback: function(value) {
              return formatCompactNumber(value);
            }
          }
        }
      },
      animations: {
        tension: {
          duration: 1000,
          easing: 'linear'
        }
      }
    }
  });
}

function initTxnMiniChart() {
  const ctx = document.getElementById('txn-mini-chart');
  if (!ctx) return;
  
  // Generate sample data for the mini chart
  const labels = generateTimeLabels(7, false);
  const data = generateRandomData(7, 300000, 500000);
  
  // Create gradient for the chart
  const chartCtx = ctx.getContext('2d');
  const gradient = chartCtx.createLinearGradient(0, 0, 0, 40);
  gradient.addColorStop(0, 'rgba(59, 130, 246, 0.2)');
  gradient.addColorStop(1, 'rgba(59, 130, 246, 0)');
  
  // Chart configuration
  txnMiniChart = new Chart(ctx, {
    type: 'line',
    data: {
      labels: labels,
      datasets: [{
        data: data,
        borderColor: '#3B82F6',
        borderWidth: 1.5,
        pointRadius: 0,
        tension: 0.4,
        fill: true,
        backgroundColor: gradient
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          display: false
        },
        tooltip: {
          enabled: false
        }
      },
      scales: {
        x: {
          display: false
        },
        y: {
          display: false
        }
      },
      elements: {
        line: {
          tension: 0.4
        }
      }
    }
  });
}

function updateChartData(timeRange) {
  if (!mainChart) return;
  
  let dataPoints = 24;
  let min = 200000;
  let max = 500000;
  
  // Adjust data based on selected time range
  switch(timeRange) {
    case '1D':
      dataPoints = 24;
      min = 200000;
      max = 500000;
      break;
    case '1W':
      dataPoints = 7;
      min = 180000;
      max = 550000;
      break;
    case '1M':
      dataPoints = 30;
      min = 150000;
      max = 600000;
      break;
    case 'ALL':
      dataPoints = 365;
      min = 100000;
      max = 700000;
      break;
  }
  
  // Generate new data
  const labels = generateTimeLabels(dataPoints, timeRange !== '1D');
  const data = generateRandomData(dataPoints, min, max);
  
  // Update chart with new data
  mainChart.data.labels = labels;
  mainChart.data.datasets[0].data = data;
  
  // Animate the update
  mainChart.update('active');
}

// Helper functions for chart data generation
function generateTimeLabels(count, showDate = true) {
  const labels = [];
  const now = new Date();
  
  for (let i = count - 1; i >= 0; i--) {
    const date = new Date(now);
    date.setHours(now.getHours() - i);
    
    let label = date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    
    if (showDate && (i === 0 || date.getHours() === 0)) {
      label = date.toLocaleDateString([], { month: 'short', day: 'numeric' }) + ' ' + label;
    }
    
    labels.push(label);
  }
  
  return labels;
}

function generateRandomData(count, min, max) {
  const data = [];
  let prev = Math.floor(Math.random() * (max - min) + min);
  
  for (let i = 0; i < count; i++) {
    // Generate a value that's within 15% of the previous value for smoother data
    const change = prev * (Math.random() * 0.3 - 0.15);
    let current = Math.floor(prev + change);
    
    // Ensure the value stays within bounds
    current = Math.max(min, Math.min(max, current));
    
    data.push(current);
    prev = current;
  }
  
  return data;
}

// Formatting helpers
function formatNumber(num) {
  return new Intl.NumberFormat().format(num);
}

function formatCompactNumber(num) {
  return new Intl.NumberFormat('en-US', {
    notation: 'compact',
    compactDisplay: 'short'
  }).format(num);
}