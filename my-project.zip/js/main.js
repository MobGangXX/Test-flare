// Main JavaScript file for the blockchain explorer

document.addEventListener('DOMContentLoaded', () => {
  // Initialize the application
  initApp();
  
  // Set up event listeners
  setupEventListeners();
});

function initApp() {
  console.log('Blockchain Explorer initialized');
  
  // Simulate data loading
  updateExplorerStats();
  loadLatestBlocks();
  loadLatestTransactions();
  
  // Initialize charts
  initializeCharts();
}

function setupEventListeners() {
  // Search functionality
  const searchInput = document.querySelector('.search-input');
  const searchButton = document.querySelector('.search-button');
  
  if (searchInput && searchButton) {
    searchInput.addEventListener('keyup', (e) => {
      if (e.key === 'Enter') {
        handleSearch(searchInput.value);
      }
    });
    
    searchButton.addEventListener('click', () => {
      handleSearch(searchInput.value);
    });
  }
  
  // Chart control buttons
  const chartControls = document.querySelectorAll('.chart-control');
  
  chartControls.forEach(control => {
    control.addEventListener('click', () => {
      // Remove active class from all controls
      chartControls.forEach(c => c.classList.remove('active'));
      
      // Add active class to clicked control
      control.classList.add('active');
      
      // Update chart based on selected time period
      updateChartData(control.textContent);
    });
  });
  
  // Connect button
  const connectButton = document.querySelector('.connect-button');
  
  if (connectButton) {
    connectButton.addEventListener('click', () => {
      handleWalletConnect();
    });
  }
}

function handleSearch(query) {
  if (!query) return;
  
  console.log(`Searching for: ${query}`);
  
  // Determine what type of search it is (address, transaction, block, token)
  if (query.startsWith('0x') && query.length === 66) {
    // Likely a transaction hash
    navigateToTransaction(query);
  } else if (query.startsWith('0x') && query.length === 42) {
    // Likely an address
    navigateToAddress(query);
  } else if (!isNaN(query)) {
    // Likely a block number
    navigateToBlock(query);
  } else {
    // Could be a token name or symbol
    searchToken(query);
  }
}

function navigateToTransaction(hash) {
  console.log(`Navigate to transaction: ${hash}`);
  // In a real app, this would navigate to the transaction details page
  alert(`Navigating to transaction: ${hash}`);
}

function navigateToAddress(address) {
  console.log(`Navigate to address: ${address}`);
  // In a real app, this would navigate to the address details page
  alert(`Navigating to address: ${address}`);
}

function navigateToBlock(blockNumber) {
  console.log(`Navigate to block: ${blockNumber}`);
  // In a real app, this would navigate to the block details page
  alert(`Navigating to block: ${blockNumber}`);
}

function searchToken(query) {
  console.log(`Search for token: ${query}`);
  // In a real app, this would search for tokens
  alert(`Searching for token: ${query}`);
}

function handleWalletConnect() {
  console.log('Connect wallet button clicked');
  // In a real app, this would trigger wallet connection
  alert('Wallet connection functionality would be implemented here');
}

function updateExplorerStats() {
  // In a real application, these values would come from an API
  const stats = {
    totalBlocks: '42,280,133',
    avgBlockTime: '1.5s',
    dailyTxns: '431.63K',
    totalTxns: '230,807,021',
    totalAddresses: '2,043,778',
    gasPrice: '35.8 Gwei'
  };
  
  // Update DOM elements with the stats
  document.getElementById('total-blocks').textContent = stats.totalBlocks;
  document.getElementById('avg-block-time').textContent = stats.avgBlockTime;
  document.getElementById('daily-txns').textContent = stats.dailyTxns;
  document.getElementById('total-txns').textContent = stats.totalTxns;
  document.getElementById('total-addresses').textContent = stats.totalAddresses;
  document.getElementById('gas-price').textContent = stats.gasPrice;
}

function loadLatestBlocks() {
  // In a real application, this data would come from an API
  const blocks = [
    { number: '42282385', txnCount: 2, timeAgo: '13s' },
    { number: '42282384', txnCount: 5, timeAgo: '27s' },
    { number: '42282383', txnCount: 3, timeAgo: '41s' },
    { number: '42282382', txnCount: 8, timeAgo: '58s' },
    { number: '42282381', txnCount: 1, timeAgo: '1m 12s' }
  ];
  
  const blocksContainer = document.getElementById('latest-blocks');
  
  // Clear existing content
  blocksContainer.innerHTML = '';
  
  // Add each block to the container
  blocks.forEach(block => {
    const blockElement = document.createElement('div');
    blockElement.className = 'block-item';
    blockElement.innerHTML = `
      <div class="block-icon">
        <i class="fa-solid fa-cube"></i>
      </div>
      <div class="block-info">
        <div class="block-number">${block.number}</div>
        <div class="block-details">
          <span class="txn-count">${block.txnCount} txns</span>
          <span class="block-time">in ${block.timeAgo}</span>
        </div>
      </div>
    `;
    
    blockElement.addEventListener('click', () => {
      navigateToBlock(block.number);
    });
    
    blocksContainer.appendChild(blockElement);
  });
}

function loadLatestTransactions() {
  // In a real application, this data would come from an API
  const transactions = [
    { hash: '0x3c6bd31020714c856550...357', status: 'success', timeAgo: '8m ago', value: '0 FLR', fee: '0.00111 FLR' },
    { hash: '0xf41d8a3e72c78455dcb2...c9d', status: 'success', timeAgo: '10m ago', value: '120 FLR', fee: '0.00087 FLR' },
    { hash: '0x91b523a05c9c287a1d79...f32', status: 'failed', timeAgo: '12m ago', value: '0 FLR', fee: '0.00054 FLR' },
    { hash: '0x3a5e98c7d4e8b32a67f1...821', status: 'success', timeAgo: '15m ago', value: '500 FLR', fee: '0.00132 FLR' },
    { hash: '0xc9f142e7b8a745d91e30...a45', status: 'success', timeAgo: '18m ago', value: '25.5 FLR', fee: '0.00095 FLR' }
  ];
  
  const txnsContainer = document.getElementById('latest-transactions');
  
  // Clear existing content
  txnsContainer.innerHTML = '';
  
  // Add each transaction to the container
  transactions.forEach(txn => {
    const txnElement = document.createElement('div');
    txnElement.className = 'txn-item';
    txnElement.innerHTML = `
      <div class="txn-type ${txn.status}">
        <span>${txn.status === 'success' ? 'Success' : 'Failed'}</span>
      </div>
      <div class="txn-info">
        <div class="txn-hash">${txn.hash}</div>
        <div class="txn-time">${txn.timeAgo}</div>
      </div>
      <div class="txn-value">
        <div class="value">${txn.value}</div>
        <div class="fee">${txn.fee}</div>
      </div>
    `;
    
    txnElement.addEventListener('click', () => {
      navigateToTransaction(txn.hash.split('...')[0]);
    });
    
    txnsContainer.appendChild(txnElement);
  });
}

// Add animation to show new transactions arriving
setInterval(() => {
  const newTxnsBanner = document.querySelector('.new-txns-banner');
  if (newTxnsBanner) {
    newTxnsBanner.style.display = 'none';
    setTimeout(() => {
      const randomTxns = Math.floor(Math.random() * 100) + 10;
      newTxnsBanner.innerHTML = `<span>${randomTxns} more transactions</span> have come in`;
      newTxnsBanner.style.display = 'block';
      newTxnsBanner.classList.add('animate-fade');
      setTimeout(() => {
        newTxnsBanner.classList.remove('animate-fade');
      }, 500);
    }, 1000);
  }
}, 30000);