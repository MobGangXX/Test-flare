// JavaScript for the blocks page

document.addEventListener('DOMContentLoaded', () => {
  // Initialize the blocks page
  initBlocksPage();
  
  // Set up event listeners
  setupBlocksPageEventListeners();
});

function initBlocksPage() {
  console.log('Blocks page initialized');
  
  // Load blocks data
  loadBlocksTableData();
}

function setupBlocksPageEventListeners() {
  // Filter dropdown
  const filterSelect = document.querySelector('.filter-select');
  
  if (filterSelect) {
    filterSelect.addEventListener('change', () => {
      loadBlocksTableData(parseInt(filterSelect.value));
    });
  }
  
  // Pagination buttons
  const paginationBtns = document.querySelectorAll('.pagination-btn');
  
  paginationBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      if (!btn.disabled && !btn.classList.contains('active')) {
        // Remove active class from all buttons
        paginationBtns.forEach(b => b.classList.remove('active'));
        
        // Add active class to clicked button
        btn.classList.add('active');
        
        // Load data for the selected page
        loadBlocksTableData();
      }
    });
  });
}

function loadBlocksTableData(count = 25) {
  // In a real application, this would fetch data from an API
  // For this demo, we'll use the mock data
  
  // Get blocks table body
  const tableBody = document.getElementById('blocks-table-body');
  
  // Clear existing content
  tableBody.innerHTML = '';
  
  // Get blocks data (5 blocks from our mock data, duplicated to reach the count)
  const blocksData = [];
  const mockBlocks = window.explorerData.getLatestBlocks();
  
  for (let i = 0; i < count; i++) {
    const mockBlock = mockBlocks[i % mockBlocks.length];
    
    // Create a copy with slightly modified data
    const block = { ...mockBlock };
    block.number = mockBlock.number - i;
    block.timestamp = mockBlock.timestamp - (i * 15000); // 15 seconds between blocks
    block.gasUsed = Math.floor(mockBlock.gasUsed * (0.9 + Math.random() * 0.2));
    
    blocksData.push(block);
  }
  
  // Add block rows to the table
  blocksData.forEach(block => {
    // Calculate percentage of gas used
    const gasUsedPercent = ((block.gasUsed / block.gasLimit) * 100).toFixed(2);
    
    // Create row
    const row = document.createElement('tr');
    row.innerHTML = `
      <td>
        <div class="block-cell">
          <div class="block-icon-small">
            <i class="fa-solid fa-cube"></i>
          </div>
          <a href="#" class="block-number-link">${block.number}</a>
        </div>
      </td>
      <td>${formatTimeAgo(block.timestamp)}</td>
      <td>${block.transactions}</td>
      <td>
        <a href="#" class="address-link">${formatAddress(block.miner)}</a>
      </td>
      <td>${formatNumber(block.gasUsed)} (${gasUsedPercent}%)</td>
      <td>${formatNumber(block.gasLimit)}</td>
      <td>${block.baseFeePerGas} Gwei</td>
    `;
    
    // Add click event to row
    row.addEventListener('click', () => {
      navigateToBlock(block.number);
    });
    
    tableBody.appendChild(row);
  });
}

// Formatting helpers
function formatTimeAgo(timestamp) {
  const seconds = Math.floor((Date.now() - timestamp) / 1000);
  
  if (seconds < 60) {
    return `${seconds} secs ago`;
  }
  
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) {
    return `${minutes} min${minutes === 1 ? '' : 's'} ${seconds % 60} secs ago`;
  }
  
  const hours = Math.floor(minutes / 60);
  if (hours < 24) {
    return `${hours} hr${hours === 1 ? '' : 's'} ${minutes % 60} min${minutes % 60 === 1 ? '' : 's'} ago`;
  }
  
  const days = Math.floor(hours / 24);
  return `${days} day${days === 1 ? '' : 's'} ago`;
}

function formatAddress(address) {
  if (!address || address.length < 10) return address;
  return `${address.slice(0, 6)}...${address.slice(-4)}`;
}

function formatNumber(num) {
  return new Intl.NumberFormat().format(num);
}

function navigateToBlock(blockNumber) {
  console.log(`Navigate to block: ${blockNumber}`);
  // In a real app, this would navigate to the block details page
  alert(`Navigating to block: ${blockNumber}`);
}