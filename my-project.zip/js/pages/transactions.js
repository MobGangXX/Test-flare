// JavaScript for the transactions page

document.addEventListener('DOMContentLoaded', () => {
  // Initialize the transactions page
  initTransactionsPage();
  
  // Set up event listeners
  setupTransactionsPageEventListeners();
});

function initTransactionsPage() {
  console.log('Transactions page initialized');
  
  // Load transactions data
  loadTransactionsTableData();
}

function setupTransactionsPageEventListeners() {
  // Filter dropdown
  const filterSelect = document.querySelector('.filter-select');
  
  if (filterSelect) {
    filterSelect.addEventListener('change', () => {
      loadTransactionsTableData(parseInt(filterSelect.value));
    });
  }
  
  // Pagination buttons
  const paginationBtns = document.querySelectorAll('.pagination-btn');
  
  paginationBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      if (!btn.disabled && !btn.classList.contains('active')) {
        // Remove active class from all buttons
        paginationBtns.forEach(b => b.classList.remove('active'));
        
        // Add active class to clicked button
        btn.classList.add('active');
        
        // Load data for the selected page
        loadTransactionsTableData();
      }
    });
  });
}

function loadTransactionsTableData(count = 25) {
  // In a real application, this would fetch data from an API
  // For this demo, we'll use the mock data
  
  // Get transactions table body
  const tableBody = document.getElementById('transactions-table-body');
  
  // Clear existing content
  tableBody.innerHTML = '';
  
  // Get transactions data (5 transactions from our mock data, duplicated to reach the count)
  const txnsData = [];
  const mockTxns = window.explorerData.getLatestTransactions();
  
  for (let i = 0; i < count; i++) {
    const mockTxn = mockTxns[i % mockTxns.length];
    
    // Create a copy with slightly modified data
    const txn = { ...mockTxn };
    txn.hash = mockTxn.hash.replace(/[0-9]/g, (match) => {
      return String.fromCharCode(48 + ((parseInt(match) + i) % 10));
    });
    txn.timestamp = mockTxn.timestamp - (i * 60000); // 1 minute between transactions
    txn.value = Math.floor(mockTxn.value * (0.9 + Math.random() * 0.2));
    txn.fee = mockTxn.fee * (0.9 + Math.random() * 0.2);
    
    txnsData.push(txn);
  }
  
  // Add transaction rows to the table
  txnsData.forEach(txn => {
    // Create row
    const row = document.createElement('tr');
    
    // Format hash for display (first 22 chars + ... + last 3 chars)
    const displayHash = `${txn.hash.slice(0, 22)}...${txn.hash.slice(-3)}`;
    
    row.innerHTML = `
      <td>
        <div class="txn-cell">
          <div class="txn-status ${txn.status}"></div>
          <a href="#" class="txn-hash-link">${displayHash}</a>
        </div>
      </td>
      <td>
        <span class="method-tag">${txn.method}</span>
      </td>
      <td>
        <a href="#" class="block-number-link">${txn.block}</a>
      </td>
      <td>${formatTimeAgo(txn.timestamp)}</td>
      <td>
        <a href="#" class="address-link">${formatAddress(txn.from)}</a>
      </td>
      <td>
        <a href="#" class="address-link">${formatAddress(txn.to)}</a>
      </td>
      <td>${txn.value} FLR</td>
      <td>${txn.fee.toFixed(5)} FLR</td>
    `;
    
    // Add click event to row
    row.addEventListener('click', () => {
      navigateToTransaction(txn.hash);
    });
    
    tableBody.appendChild(row);
  });
}

// Formatting helpers
function formatTimeAgo(timestamp) {
  const seconds = Math.floor((Date.now() - timestamp) / 1000);
  
  if (seconds < 60) {
    return `${seconds} secs ago`;
  }
  
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) {
    return `${minutes} mins ago`;
  }
  
  const hours = Math.floor(minutes / 60);
  if (hours < 24) {
    return `${hours} hrs ago`;
  }
  
  const days = Math.floor(hours / 24);
  return `${days} days ago`;
}

function formatAddress(address) {
  if (!address || address.length < 10) return address;
  return `${address.slice(0, 6)}...${address.slice(-4)}`;
}

function navigateToTransaction(hash) {
  console.log(`Navigate to transaction: ${hash}`);
  // In a real app, this would navigate to the transaction details page
  alert(`Navigating to transaction: ${hash}`);
}

function navigateToBlock(blockNumber) {
  console.log(`Navigate to block: ${blockNumber}`);
  // In a real app, this would navigate to the block details page
  alert(`Navigating to block: ${blockNumber}`);
}