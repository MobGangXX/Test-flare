// Data management for the blockchain explorer

// Mock data for demonstration purposes
// In a real application, this would be replaced with API calls

const mockData = {
  // Network stats
  networkStats: {
    totalBlocks: 42280133,
    avgBlockTime: 1.5,
    dailyTransactions: 431630,
    totalTransactions: 230807021,
    totalAddresses: 2043778,
    gasPrice: 35.8,
    networkUtilization: 5.13
  },
  
  // Block data
  blocks: [
    {
      number: 42282385,
      hash: '0x8a23f85930e788ae81f317215e1cd7b4b587c15dc75cf0f4e342f92074f51024',
      timestamp: Date.now() - 13000,
      transactions: 2,
      miner: '0x7da82c7ab4771ff031b66538d2fb9b0b047f6cf9',
      gasUsed: 124568,
      gasLimit: 8000000,
      baseFeePerGas: 35.8,
      extraData: 'Flare Mainnet',
      size: 12453
    },
    {
      number: 42282384,
      hash: '0x1b69542c48e7c98a92f6f47e12a89a35e45d84d0a1086e3e91e753c3a46e6e9b',
      timestamp: Date.now() - 27000,
      transactions: 5,
      miner: '0x7da82c7ab4771ff031b66538d2fb9b0b047f6cf9',
      gasUsed: 256984,
      gasLimit: 8000000,
      baseFeePerGas: 35.8,
      extraData: 'Flare Mainnet',
      size: 28741
    },
    {
      number: 42282383,
      hash: '0x6d42c44f759f6296a22cd3e6ca0f7b3f6d2c9989f1b2973e6a89fe93b8c22c8d',
      timestamp: Date.now() - 41000,
      transactions: 3,
      miner: '0x2b888954421b424c5d3d9ce9bb67c9bd47669a36',
      gasUsed: 178942,
      gasLimit: 8000000,
      baseFeePerGas: 35.8,
      extraData: 'Flare Mainnet',
      size: 18962
    },
    {
      number: 42282382,
      hash: '0x3a5c7d9e8b16f75c4e9d82f76c5e8a2b9c5d1e7f3a8d4b6c2e9f1a3b5d7c9e8a',
      timestamp: Date.now() - 58000,
      transactions: 8,
      miner: '0x7da82c7ab4771ff031b66538d2fb9b0b047f6cf9',
      gasUsed: 398745,
      gasLimit: 8000000,
      baseFeePerGas: 35.8,
      extraData: 'Flare Mainnet',
      size: 42156
    },
    {
      number: 42282381,
      hash: '0x9c8b7a6d5e4f3c2b1a9d8e7f6c5b4a3d2c1b0f9e8d7c6b5a4f3e2d1c0b9a8f7e',
      timestamp: Date.now() - 72000,
      transactions: 1,
      miner: '0x2b888954421b424c5d3d9ce9bb67c9bd47669a36',
      gasUsed: 89652,
      gasLimit: 8000000,
      baseFeePerGas: 35.8,
      extraData: 'Flare Mainnet',
      size: 9874
    }
  ],
  
  // Transaction data
  transactions: [
    {
      hash: '0x3c6bd31020714c856550357a3985ede76c858e33a1e3bf22d10dc737a3b0f357',
      block: 42282385,
      timestamp: Date.now() - 480000,
      from: '0x7da82c7ab4771ff031b66538d2fb9b0b047f6cf9',
      to: '0x2b888954421b424c5d3d9ce9bb67c9bd47669a36',
      value: 0,
      fee: 0.00111,
      gasPrice: 35.8,
      gasLimit: 21000,
      gasUsed: 21000,
      status: 'success',
      method: 'Transfer',
      confirmations: 10
    },
    {
      hash: '0xf41d8a3e72c78455dcb2c98d31c7b3f5a8d9e6b7c5a4d3e2f1g0h9i8j7k6l5c9d',
      block: 42282384,
      timestamp: Date.now() - 600000,
      from: '0x2b888954421b424c5d3d9ce9bb67c9bd47669a36',
      to: '0x9a8b7c6d5e4f3g2h1i0j9k8l7m6n5o4p3q2r1s0t',
      value: 120,
      fee: 0.00087,
      gasPrice: 35.8,
      gasLimit: 21000,
      gasUsed: 21000,
      status: 'success',
      method: 'Transfer',
      confirmations: 12
    },
    {
      hash: '0x91b523a05c9c287a1d795d27a9fb536291b9c75a4d8f6e3b2c1a0d9e8f7b6f32',
      block: 42282383,
      timestamp: Date.now() - 720000,
      from: '0x3c4d5e6f7g8h9i0j1k2l3m4n5o6p7q8r9s0t1u2v',
      to: '0xa9b8c7d6e5f4g3h2i1j0k9l8m7n6o5p4q3r2s1t0',
      value: 0,
      fee: 0.00054,
      gasPrice: 35.8,
      gasLimit: 150000,
      gasUsed: 15000,
      status: 'failed',
      method: 'Contract Call',
      confirmations: 15
    },
    {
      hash: '0x3a5e98c7d4e8b32a67f1d5e9c8b7a6f5e4d3c2b1a0f9e8d7c6b5a4d3e2f1821',
      block: 42282382,
      timestamp: Date.now() - 900000,
      from: '0x7da82c7ab4771ff031b66538d2fb9b0b047f6cf9',
      to: '0x1a2b3c4d5e6f7g8h9i0j1k2l3m4n5o6p7q8r9s0',
      value: 500,
      fee: 0.00132,
      gasPrice: 35.8,
      gasLimit: 21000,
      gasUsed: 21000,
      status: 'success',
      method: 'Transfer',
      confirmations: 18
    },
    {
      hash: '0xc9f142e7b8a745d91e30f6a859d2c7b6a5e4d3c2b1a0f9e8d7c6b5a4d3e2a45',
      block: 42282381,
      timestamp: Date.now() - 1080000,
      from: '0x2b888954421b424c5d3d9ce9bb67c9bd47669a36',
      to: '0xb8a7c6d5e4f3g2h1i0j9k8l7m6n5o4p3q2r1s0t',
      value: 25.5,
      fee: 0.00095,
      gasPrice: 35.8,
      gasLimit: 21000,
      gasUsed: 21000,
      status: 'success',
      method: 'Transfer',
      confirmations: 20
    }
  ],
  
  // Token data
  tokens: [
    {
      address: '0x1234567890abcdef1234567890abcdef12345678',
      name: 'Flare',
      symbol: 'FLR',
      decimals: 18,
      totalSupply: 10000000000,
      holders: 987654
    },
    {
      address: '0xabcdef1234567890abcdef1234567890abcdef12',
      name: 'Wrapped Flare',
      symbol: 'WFLR',
      decimals: 18,
      totalSupply: 2500000000,
      holders: 56789
    },
    {
      address: '0x7890abcdef1234567890abcdef1234567890abcd',
      name: 'Flare Dollar',
      symbol: 'FUSD',
      decimals: 6,
      totalSupply: 5000000000,
      holders: 123456
    }
  ]
};

// Functions to retrieve data
function getNetworkStats() {
  return mockData.networkStats;
}

function getLatestBlocks(count = 5) {
  return mockData.blocks.slice(0, count);
}

function getLatestTransactions(count = 5) {
  return mockData.transactions.slice(0, count);
}

function getBlockByNumber(blockNumber) {
  return mockData.blocks.find(block => block.number === parseInt(blockNumber));
}

function getTransactionByHash(hash) {
  return mockData.transactions.find(tx => tx.hash.startsWith(hash));
}

function getTokenBySymbol(symbol) {
  return mockData.tokens.find(token => token.symbol.toLowerCase() === symbol.toLowerCase());
}

function getAddressTransactions(address, count = 10) {
  return mockData.transactions.filter(tx => 
    tx.from.toLowerCase() === address.toLowerCase() || 
    tx.to.toLowerCase() === address.toLowerCase()
  ).slice(0, count);
}

// Function to generate time-relative string (e.g., "2 minutes ago")
function getTimeAgo(timestamp) {
  const seconds = Math.floor((Date.now() - timestamp) / 1000);
  
  if (seconds < 60) {
    return `${seconds}s ago`;
  }
  
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) {
    return `${minutes}m ago`;
  }
  
  const hours = Math.floor(minutes / 60);
  if (hours < 24) {
    return `${hours}h ago`;
  }
  
  const days = Math.floor(hours / 24);
  return `${days}d ago`;
}

// Export functions
window.explorerData = {
  getNetworkStats,
  getLatestBlocks,
  getLatestTransactions,
  getBlockByNumber,
  getTransactionByHash,
  getTokenBySymbol,
  getAddressTransactions,
  getTimeAgo
};